package com.lab;
import com.lab.Cctv;
public class Main {

	public static void main(String[] args) {
		
		Cctv c1 = new Cctv("White", "Dome", 30, 360, 90);
			System.out.println("Properties of CCTV C1: ");
			System.out.println("Color: " + c1.getColor());
			System.out.println("CCTV Type: " + c1.getType());
			System.out.println("Optical Zoom: " + c1.getOpticalzoom() + "X");
			System.out.println("Viewing Angle: " + c1.getViewingangle() + " Degrees");
			System.out.println("Recording Time: " + c1.getRecordingtime() + " Days");
			
		
	}

}
